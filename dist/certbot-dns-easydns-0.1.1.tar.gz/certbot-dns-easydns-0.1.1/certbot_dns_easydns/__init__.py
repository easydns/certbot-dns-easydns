from ._version import __version__

__all__ = ["_version", "dns_easydns"]
